export interface Cliente {
    clienteId: number;
    nomeCliente: string;
    email: string;
    telefone: string
}